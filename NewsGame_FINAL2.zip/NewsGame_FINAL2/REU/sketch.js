var coins;
var player;
var score = 0;
var img;

function setup() {
  createCanvas(720, 720);
  coins = new Group();
  for (var i = 0; i < 51; i++) {
    var c = createSprite(
      random(100, width-100),
      random(100, height-100),
      10, 10);
    c.shapeColor = color(139,69,19);
    coins.add(c);
    img = loadImage("logo2.png");
  }
  
  player = createSprite(40, 40, 40, 40);
  player.shapeColor = color(255);
}

function draw() {
  
  background(img, 0, 0);
  textSize(25);
  fill(237,67,55);
  //text("Round 'Em Up", 10, 30);
  textSize(20);
  text('Collect The "Coins"', 251, 65);
  
  
  
  player.velocity.x = 
    (mouseX-player.position.x)*0.1;
  player.velocity.y = 
    (mouseY-player.position.y)*0.1;
  player.overlap(coins, getCoin);
  drawSprites();
  fill(237,67,55);
  noStroke();
  textSize(100);
  textAlign(CENTER, CENTER);
  if (coins.length > 0) {
    text(score, width/2, height/2);
  }
  else {
    text("you win!", width/2, height/2);
  }
}


function getCoin(player, coin) {
  coin.remove();
  score += 1;
}